﻿using AreaComputerLibrary.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaComputerLibrary.Classes
{
    public class Shape : IShape
    {
        private Interfaces.IShape _shape;
        public double area => _shape.area;

        public Shape(Interfaces.IShape shape)
        {
            _shape = shape;
        }
    }
}
