﻿using AreaComputerLibrary.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaComputerLibrary.Classes
{
    public class Triangle : IShape
    {
        //Первая сторона треугольника
        public double Side1 { get; set; }

        //Вторая сторона треугольника
        public double Side2 { get; set; }

        //Третья сторона треугольника
        public double Side3 { get; set; }

        public double area
        {
            get
            {
                var p = (Side1 + Side2 + Side3) / 2;
                return Math.Sqrt(p * (p - Side1) * (p - Side2) * (p - Side3));
            }
        }

        public Triangle()
        {
            Side1 = Side2 = Side3 = 0;
        }

        public Triangle(double side1, double side2, double side3)
        {
            if (!IsValidTriangle(side1, side2, side3))
            {
                throw new ArgumentException("Invalid triangle sides.");
            }

            Side1 = side1;
            Side2 = side2;
            Side3 = side3;
        }

        public bool IsValidTriangle(double side1, double side2, double side3)
        {
            bool isValid = side1 + side2 > side3 && side1 + side3 > side2 && side2 + side3 > side1;

            if (isValid)
            {
                // Дополнительная проверка на прямоугольный треугольник (теорема Пифагора)
                isValid = isValid && (Math.Pow(side1, 2) + Math.Pow(side2, 2) == Math.Pow(side3, 2)
                    || Math.Pow(side2, 2) + Math.Pow(side3, 2) == Math.Pow(side1, 2)
                    || Math.Pow(side1, 2) + Math.Pow(side3, 2) == Math.Pow(side2, 2));
            }

            return isValid;
        }

    }
}