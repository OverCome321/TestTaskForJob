﻿using AreaComputerLibrary.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaComputerLibrary.Classes
{
    public class Circle : IShape
    {
        private double radius;

        public double Radius
        {
            get { return radius; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Radius cannot be negative");
                }
                radius = value;
            }
        }

        public double area => Math.PI * Math.Pow(Radius, 2);

        public Circle()
        {
            Radius = 0;
        }

        public Circle(double radius)
        {
            Radius = radius;
        }
    }

}
